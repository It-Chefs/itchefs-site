# IT Chefs™ Site

Minimal Docusaurus-lite scaffold. Publishes docs and Kitchen exports.

## Sync Kitchen Content
This repo includes a workflow `.github/workflows/sync-kitchen.yml` that
clones the private Kitchen and copies `/export/site` into `docs/kitchen/`.

### Setup
1. Create a fine-grained GitHub PAT with `read:org` and `repo` (contents:read) on the IT-Chefs org.
2. Add it as a Repo Secret here: `KITCHEN_READ_TOKEN`.
3. Push to `main` or wait for the nightly schedule.

## Local dev
npm install
npm run start
